package com.thilini.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.thilini.product.modal.Product;
import com.thilini.product.service.ProductService;

@RestController

@RequestMapping(value="/emscloud")
public class ProductController {
	
	
	@Autowired
	ProductService productService;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/product", method= RequestMethod.GET)
	public List<Product> fetchAllEmployees(){
	   

		return productService.fetchProduct();
	}

}
