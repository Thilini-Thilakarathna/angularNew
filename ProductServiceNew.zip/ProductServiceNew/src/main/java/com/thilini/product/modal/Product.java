package com.thilini.product.modal;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import javax.persistence.Entity;


public class Product {
	
	public Product(Integer id, String name, String des, Double price, String img) {
		super();
		this.id = id;
		this.name = name;
		this.des = des;
		this.img = img;
		this.price = price;
	}
	Integer id;
	String name;
	String des;
	String img;
	Double price;
	
	
	
	
	public Integer getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDes() {
		return des;
	}

	public String getImg() {
		return img;
	}
	
	public Double getPrice() {
		return price;
	}
	

}
