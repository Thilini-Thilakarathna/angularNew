package com.thilini.product.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;

import com.thilini.product.modal.Product;


@Service
public class ProductService {
	List arList;
	
	public List<Product> fetchProduct() {
		
		try {

		
		

			
			File f2= new File("C:\\Users\\ththilini\\Desktop\\AngularTest\\ProductServiceNew\\img\\rot1.png");
			File f1= new File("C:\\Users\\ththilini\\Desktop\\AngularTest\\ProductServiceNew\\img\\ger3.png");
			File f3= new File("C:\\Users\\ththilini\\Desktop\\AngularTest\\ProductServiceNew\\img\\bul1.png");
			File f4= new File("C:\\Users\\ththilini\\Desktop\\AngularTest\\ProductServiceNew\\img\\labri-1.png");
			File f5= new File("C:\\Users\\ththilini\\Desktop\\AngularTest\\ProductServiceNew\\img\\lion1.png");
			File f6= new File("C:\\Users\\ththilini\\Desktop\\AngularTest\\ProductServiceNew\\img\\labri-2.png");
			File f7= new File("C:\\Users\\ththilini\\Desktop\\AngularTest\\ProductServiceNew\\img\\bul2.png");
			File f8= new File("C:\\Users\\ththilini\\Desktop\\AngularTest\\ProductServiceNew\\img\\labri3.png"); 	
			byte[] fileContent = FileUtils.readFileToByteArray(f1);
			String encodedString = Base64.getEncoder().encodeToString(fileContent);
			byte[] fileContent1 = FileUtils.readFileToByteArray(f2);
			String encodedString1 = Base64.getEncoder().encodeToString(fileContent1);
			byte[] fileContent2 = FileUtils.readFileToByteArray(f3);
			String encodedString2 = Base64.getEncoder().encodeToString(fileContent2);
			byte[] fileContent3 = FileUtils.readFileToByteArray(f4);
			String encodedString3 = Base64.getEncoder().encodeToString(fileContent3);
			byte[] fileContent4 = FileUtils.readFileToByteArray(f5);
			String encodedString4 = Base64.getEncoder().encodeToString(fileContent4);
			byte[] fileContent5 = FileUtils.readFileToByteArray(f6);
			String encodedString5 = Base64.getEncoder().encodeToString(fileContent5);
			byte[] fileContent6 = FileUtils.readFileToByteArray(f7);
			String encodedString6 = Base64.getEncoder().encodeToString(fileContent6);
			byte[] fileContent7 = FileUtils.readFileToByteArray(f8);
			String encodedString7 = Base64.getEncoder().encodeToString(fileContent7);
			
			
			
			Product pr= new Product(1, "Lucy","rottweiler, black, 2 years,female",35000.00,encodedString);
			Product pr1= new Product(2, "Sam","German Shepard, black, 1 years,male",15000.00,encodedString1);
			Product pr2= new Product(3, "Lucky","bull dog, black, 3 years,female",10000.00,encodedString2);
			Product pr3= new Product(4, "Max","Labri Dog, black, 1 years,male",21000.00,encodedString3);
			Product pr4= new Product(5, "Jake","Lion Shepard, black, 2 years,male",18000.00,encodedString4);
			Product pr5= new Product(6, "Rex","Labri Dog, black, 2 years,male",25000.00,encodedString5);
			Product pr6= new Product(7, "Oscar","bull dog, black, 1 years,male",12000.00,encodedString6);
			Product pr7= new Product(8, "Rudy","Labri Dog, black, 2 years,male",35000.00,encodedString7);
			
			
			arList= new ArrayList();
			
			arList.add(pr);
			arList.add(pr1);
			arList.add(pr2);
			arList.add(pr3);
			arList.add(pr4);
			arList.add(pr5);
			arList.add(pr6);
			arList.add(pr7);

				
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return arList;
		
		
		
		}

}
