import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/model/product';
import { LocalStorage } from '@ngx-pwa/local-storage';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {
  product:Product[]=[]
  constructor(localStorage:LocalStorage) { }

  ngOnInit() {
    this.product= JSON.parse(localStorage.getItem('cart'));
    console.log(this.product);
  }

}
