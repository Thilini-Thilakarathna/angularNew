import { Component, OnInit } from '@angular/core';
import { LocalStorage } from '@ngx-pwa/local-storage';
import { Product } from 'src/app/model/product';
import { ProductItemComponent } from '../../shopping-cart/product-list/product-item/product-item.component';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
 product:Product[]=[]
 
  constructor() { }

  ngOnInit() {
    
  }


load(){
  this.product= JSON.parse(localStorage.getItem('cart'));
    console.log(localStorage.getItem('cart').length);
}

}
