export class Type {
    id: number;
    name: String;
}
